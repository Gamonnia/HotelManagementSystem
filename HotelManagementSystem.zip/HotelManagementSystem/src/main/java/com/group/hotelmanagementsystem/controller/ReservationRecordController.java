package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.ReservationRecord;
import com.group.hotelmanagementsystem.service.ReservationRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("reservationRecord")
public class ReservationRecordController {

    @Autowired
    private ReservationRecordService reservationRecordService;


    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("deleteByPrimaryKey") Integer reservationRecordID) {
        try {
            return reservationRecordService.deleteByPrimaryKey(reservationRecordID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody ReservationRecord record) {
        try {
            return reservationRecordService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody ReservationRecord record) {
        try {
            return reservationRecordService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectByPrimaryKey")
    public ReservationRecord selectByPrimaryKey(@RequestParam("reservationRecordID") Integer reservationRecordID) {
        try {
            return reservationRecordService.selectByPrimaryKey(reservationRecordID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody ReservationRecord record) {
        try {
            return reservationRecordService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody ReservationRecord record) {
        try {
            return reservationRecordService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<ReservationRecord> selectAll() {
        try {
            return reservationRecordService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
