package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.Staff;
import com.group.hotelmanagementsystem.service.StaffService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("staff")
public class StaffController {

    @Autowired
    private StaffService staffService;

    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("staffID") Integer staffID) {
        try {
            return staffService.deleteByPrimaryKey(staffID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody Staff record) {
        try {
            return staffService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody Staff record) {
        try {
            return staffService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectByPrimaryKey")
    public Staff selectByPrimaryKey(@RequestParam("staffID") Integer staffID) {
        try {
            return staffService.selectByPrimaryKey(staffID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody Staff record) {
        try {
            return staffService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody Staff record) {
        try {
            return staffService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<Staff> selectAll() {
        try {
            return staffService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
