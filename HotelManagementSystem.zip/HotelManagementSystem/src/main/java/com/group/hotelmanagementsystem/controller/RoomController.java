package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.Room;
import com.group.hotelmanagementsystem.service.RoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("room")
public class RoomController {

    @Autowired
    private RoomService roomService;

    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("roomID") Integer roomID) {
        try {
            return roomService.deleteByPrimaryKey(roomID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody Room record) {
        try {
            return roomService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody Room record) {
        try {
            return roomService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectByPrimaryKey")
    public Room selectByPrimaryKey(@RequestParam("roomID") Integer roomID) {
        try {
            return roomService.selectByPrimaryKey(roomID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody Room record) {
        try {
            return roomService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody Room record) {
        try {
            return roomService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<Room> selectAll() {
        try {
            return roomService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
