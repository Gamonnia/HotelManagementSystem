package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.Department;
import com.group.hotelmanagementsystem.service.DepartmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("department")
public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;

    @RequestMapping(value = "/delete")
    public boolean delete(@RequestParam("departmentID") Integer departmentID) {
        try {
            return departmentService.deleteByPrimaryKey(departmentID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody Department record) {
        try {
            return departmentService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody Department record) {
        try {
            return departmentService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectByPrimaryKey")
    public Department selectByPrimaryKey(@RequestParam("departmentID") Integer departmentID) {
        try {
            return departmentService.selectByPrimaryKey(departmentID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updatePrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody Department record) {
        try {
            return departmentService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody Department record) {
        try {
            return departmentService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<Department> selectAll() {
        try {
            return departmentService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
