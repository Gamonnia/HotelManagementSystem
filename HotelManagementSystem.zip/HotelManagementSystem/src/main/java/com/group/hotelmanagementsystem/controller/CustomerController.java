package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.Customer;

import com.group.hotelmanagementsystem.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @RequestMapping("/request")
    public Boolean deleteByPrimaryKey(@RequestParam("customerID") Integer customerID) {
        try {
            return customerService.deleteByPrimaryKey(customerID) >=1 ;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/insert")
    public Boolean insert(@RequestBody Customer record) {
        try {
            return customerService.insert(record) >=1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/insertSelective")
    public Boolean insertSelective(@RequestBody Customer record) {
        try {
            return customerService.insertSelective(record) >=1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/selectByPrimaryKey")
    public Customer selectByPrimaryKey(@RequestParam Integer customerID) {
        try {
            return customerService.selectByPrimaryKey(customerID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/updateByPrimaryKeySelective")
    public Boolean updateByPrimaryKeySelective(@RequestBody Customer record) {
        try {
            return customerService.updateByPrimaryKeySelective(record) >=1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/upDateByPrimaryKey")
    public Boolean updateByPrimaryKey(@RequestBody Customer record) {
        try {
            return customerService.updateByPrimaryKey(record) >=1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/selectAll")
    public List<Customer> selectAll() {
        try {
            return customerService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }
}
