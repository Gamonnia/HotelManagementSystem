package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.RoomType;
import com.group.hotelmanagementsystem.service.RoomTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("/roomType")
public class RoomTypeController {

    @Autowired
    private RoomTypeService roomTypeService;

    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("roomTypeID") Integer roomTypeID) {
        try {
            return roomTypeService.deleteByPrimaryKey(roomTypeID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody RoomType record) {
        try {
            return roomTypeService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody RoomType record) {
        try {
            return roomTypeService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(value = "/selectByPrimaryKey")
    public RoomType selectByPrimaryKey(@RequestParam("roomTypeID") Integer roomTypeID) {
        try {
            return roomTypeService.selectByPrimaryKey(roomTypeID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody RoomType record) {
        try {
            return roomTypeService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody RoomType record) {
        try {
            return roomTypeService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<RoomType> selectAll() {
        try {
            return roomTypeService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
