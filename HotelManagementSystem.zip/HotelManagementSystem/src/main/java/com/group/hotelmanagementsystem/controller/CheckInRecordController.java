package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.CheckInRecord;
import com.group.hotelmanagementsystem.entity.Customer;
import com.group.hotelmanagementsystem.service.CheckInRecordService;
import com.group.hotelmanagementsystem.service.CustomerService;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("checkInRecord")
public class CheckInRecordController {

    @Autowired
    private CheckInRecordService checkInRecordService;

    @Autowired CustomerService customerService;

    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("checkInRecordID") Integer checkInRecordID) {
        try {
            return checkInRecordService.deleteByPrimaryKey(checkInRecordID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody ParamOfCheckInRecord param) {
        try {
            customerService.insert(param.getCustomer());
            param.getCheckInRecord().setCustomerID(param.getCustomer().getCustomerID());
            return checkInRecordService.insert(param.getCheckInRecord()) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody ParamOfCheckInRecord param) {
        try {
            customerService.insertSelective(param.getCustomer());
            param.getCheckInRecord().setCustomerID(param.getCustomer().getCustomerID());
            return checkInRecordService.insertSelective(param.getCheckInRecord()) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "selectByPrimaryKey")
    public CheckInRecord selectByPrimaryKey(@RequestParam("checkInRecordID") Integer checkInRecordID) {
        try {
            return checkInRecordService.selectByPrimaryKey(checkInRecordID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody CheckInRecord record) {
        try{
            return checkInRecordService.updateByPrimaryKey(record) >= 1;
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody CheckInRecord record) {
        try {
            return checkInRecordService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @RequestMapping(value = "/selectAll")
    public List<CheckInRecord> selectAll() {
        try {
            return checkInRecordService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Setter
    @Getter
    public static class ParamOfCheckInRecord {
        private CheckInRecord checkInRecord;
        private Customer customer;
    }
}
