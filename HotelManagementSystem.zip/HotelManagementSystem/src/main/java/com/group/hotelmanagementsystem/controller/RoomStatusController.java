package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.RoomStatus;
import com.group.hotelmanagementsystem.service.RoomStatusService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("roomStatus")
public class RoomStatusController {

    @Autowired
    private RoomStatusService roomStatusService;

    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("roomStatusID") Integer roomStatusID) {
        try {
            return roomStatusService.deleteByPrimaryKey(roomStatusID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody RoomStatus record) {
        try {
            return roomStatusService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody RoomStatus record) {
        try {
            return roomStatusService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectByPrimaryKey")
    public RoomStatus selectByPrimaryKey(@RequestParam("roomStatusID") Integer roomStatusID) {
        try {
            return roomStatusService.selectByPrimaryKey(roomStatusID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody RoomStatus record) {
        try {
            return roomStatusService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody RoomStatus record) {
        try {
            return roomStatusService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<RoomStatus> selectAll() {
        try {
            return roomStatusService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
