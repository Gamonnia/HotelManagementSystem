package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.FinancialRecord;
import com.group.hotelmanagementsystem.service.FinancialRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("financialRecord")
public class FinancialRecordController {

    @Autowired
    private FinancialRecordService financialRecordService;

    @RequestMapping("/deleteByPrimaryKey")
    public Boolean deleteByPrimaryKey(@RequestParam("financialRecordID") Integer financialRecordID) {
        try {
            return financialRecordService.deleteByPrimaryKey(financialRecordID) >=1 ;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/insert")
    public Boolean insert(@RequestBody FinancialRecord record) {
        try {
            return financialRecordService.insert(record) >=1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }finally {
        }
    }


    @RequestMapping("/insertSelective")
    public Boolean insertSelective(@RequestBody FinancialRecord record) {
        try {
            return financialRecordService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/selectByPrimaryKey")
    public FinancialRecord selectByPrimaryKey(@RequestParam("financialRecordID") Integer financialRecordID) {
        try {
            return financialRecordService.selectByPrimaryKey(financialRecordID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/updateByPrimaryKeySelective")
    public Boolean updateByPrimaryKeySelective(@RequestBody FinancialRecord record) {
        try {
            return financialRecordService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("updateByPrimaryKey")
    public Boolean updateByPrimaryKey(@RequestBody FinancialRecord record) {
        try {
            return financialRecordService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/selectAll")
    public List<FinancialRecord> selectAll() {
        try {
            return financialRecordService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }
}
