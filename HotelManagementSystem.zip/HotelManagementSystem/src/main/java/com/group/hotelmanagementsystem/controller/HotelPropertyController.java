package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.HotelProperty;
import com.group.hotelmanagementsystem.service.HotelPropertyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@Slf4j
@RequestMapping("hotelPropertyController")
public class HotelPropertyController {

    @Autowired
    private HotelPropertyService hotelPropertyService;


    @RequestMapping("/deleteByPrimaryKey")
    public Boolean deleteByPrimaryKey(@RequestParam("departmentID") Integer departmentID) {
        try {
            return hotelPropertyService.deleteByPrimaryKey(departmentID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }


    @RequestMapping("/insert")
    public Boolean insert(@RequestBody HotelProperty record) {
        try {
            return hotelPropertyService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }

   @RequestMapping("/insertSelective")
   public Boolean insertSelective(@RequestBody HotelProperty record) {
       try {
           return hotelPropertyService.insertSelective(record) >= 1;
       } catch (Exception e) {
           throw new RuntimeException(e);
       } finally {
       }
   }

   @RequestMapping("/selectByPrimaryKey")
   public HotelProperty selectByPrimaryKey(@RequestParam("itemID") Integer itemID) {
       try {
           return hotelPropertyService.selectByPrimaryKey(itemID);
       } catch (Exception e) {
           throw new RuntimeException(e);
       } finally {
       }
   }


  @RequestMapping("/updateByPrimaryKeySelective")
  public Boolean updateByPrimaryKeySelective(@RequestBody HotelProperty record) {
      try {
          return hotelPropertyService.updateByPrimaryKeySelective(record) >= 1;
      } catch (Exception e) {
          throw new RuntimeException(e);
      } finally {
      }
  }


   @RequestMapping("/updateByPrimaryKey")
   public Boolean updateByPrimaryKey(@RequestBody HotelProperty record) {
       try {
           return hotelPropertyService.updateByPrimaryKey(record) >= 1;
       } catch (Exception e) {
           throw new RuntimeException(e);
       } finally {
       }
   }


    @RequestMapping("/selectAll")
    public List<HotelProperty> selectAll() {
        try {
            return hotelPropertyService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
        }
    }
}
