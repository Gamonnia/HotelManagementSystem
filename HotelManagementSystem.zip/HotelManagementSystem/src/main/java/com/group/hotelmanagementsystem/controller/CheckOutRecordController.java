package com.group.hotelmanagementsystem.controller;

import com.group.hotelmanagementsystem.entity.CheckOutRecord;
import com.group.hotelmanagementsystem.service.CheckOutRecordService;
import com.group.hotelmanagementsystem.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@CrossOrigin
@Slf4j
@RequestMapping("checkOutRecord")
public class CheckOutRecordController {

    // 注入checkOutRecordService
    @Autowired
    private CheckOutRecordService checkOutRecordService;

    @Autowired
    private CustomerService customerService;

    @RequestMapping(value = "/deleteByPrimaryKey")
    public boolean deleteByPrimaryKey(@RequestParam("RecordID") Integer checkOutRecordID) {
        try {
            return checkOutRecordService.deleteByPrimaryKey(checkOutRecordID) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insert")
    public boolean insert(@RequestBody CheckOutRecord record) {
        try {
            return checkOutRecordService.insert(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/insertSelective")
    public boolean insertSelective(@RequestBody CheckOutRecord record) {
        try {
            return checkOutRecordService.insertSelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectByPrimaryKey")
    public CheckOutRecord selectByPrimaryKey(@RequestParam(value = "checkOutRecordID") Integer checkOutRecordID) {
        try {
            return checkOutRecordService.selectByPrimaryKey(checkOutRecordID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKey")
    public boolean updateByPrimaryKey(@RequestBody CheckOutRecord record) {
        try {
            return checkOutRecordService.updateByPrimaryKey(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/updateByPrimaryKeySelective")
    public boolean updateByPrimaryKeySelective(@RequestBody CheckOutRecord record) {
        try {
            return checkOutRecordService.updateByPrimaryKeySelective(record) >= 1;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/selectAll")
    public List<CheckOutRecord> selectAll() {
        try {
            return checkOutRecordService.selectAll();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
